// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JNCSInvalidSetViewException.java

package com.ermapper.ecw;


// Referenced classes of package com.ermapper.ecw:
//            JNCSException

public class JNCSInvalidSetViewException extends JNCSException
{

    public JNCSInvalidSetViewException()
    {
    }

    public JNCSInvalidSetViewException(String s)
    {
        super(s);
    }
}
