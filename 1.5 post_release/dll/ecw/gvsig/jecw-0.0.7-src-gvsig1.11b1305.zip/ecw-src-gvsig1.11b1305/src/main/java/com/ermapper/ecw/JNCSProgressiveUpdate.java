// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JNCSProgressiveUpdate.java

package com.ermapper.ecw;


public interface JNCSProgressiveUpdate
{

    public abstract void refreshUpdate(int i, int j, double d, double d1, double d2, double d3);

    public abstract void refreshUpdate(int i, int j, int k, int l, int i1, int j1);
}
