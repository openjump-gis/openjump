// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JNCSDatasetPoint.java

package com.ermapper.util;


public class JNCSDatasetPoint
{

    public JNCSDatasetPoint()
    {
        x = 0;
        y = 0;
    }

    public JNCSDatasetPoint(int i, int j)
    {
        x = i;
        y = j;
    }

    public int x;
    public int y;
}
